const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let articleSchema = new Schema({
    title :{
        type: "string",
        required:"Title is required"
    },
    content :{
        type:"string",
        required:"content is ofcourse required",
        unique: "It must be unique to avoid redundency"
    },
    objectId: {
        type: Schema.Types.ObjectId,
        ref:"User"
    }
})

let Article = mongoose.model("Article",articleSchema);
module.exports = Article;
